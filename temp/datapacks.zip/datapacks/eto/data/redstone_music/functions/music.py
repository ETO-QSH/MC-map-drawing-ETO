
from mido import MidiFile; import copy; import os

file = '\\星茶会.mid'; mid = MidiFile(file)
tip = 0; Dict = {}; List = []; new_List = []
name = os.path.splitext(os.path.split(file)[1])[0]

for track in mid.tracks:
    for msg in track:
        if (msg.type == 'note_on' or msg.type == 'note_off'):
            note = [j.split('_') if j[0] == 's' else j.split('=') for j in ('state'+str(msg)[4:]).split(' ')]
            for k in range(len(note)):
                Dict[note[k][0]] = note[k][1]
            Dict['channel'] = int(Dict['channel']); Dict['time'] = int(Dict['time']) + tip
            Dict['note'] = int(Dict['note']) - 21; Dict['velocity'] = int(Dict['velocity']); tip = Dict['time']
            if Dict['state'] == 'on':
                del Dict['state']; Dict['time'] = int((Dict['time'] + 80) // 81); List.append(copy.deepcopy(Dict))
        else:
            try:
                bmp = int(256000000/(20*msg.tempo))
            except AttributeError:
                pass

for k in List:
    if len(new_List) > 0 and new_List[-1]['time'] == k['time']:
        new_List[-1]['note'].append((k['channel'], k['note'], k['velocity']))
    else:
        new_List.append({'time': k['time'], 'note': [(k['channel'], k['note'], k['velocity'])]})

new_new_List = copy.deepcopy(new_List)

for k in range(len(new_List)):
    if k != 0:
        new_new_List[k]['time'] = new_List[k]['time'] - new_List[k-1]['time']

new_new_new_List = []; channel = ['harp']; z = 9

for p in range(len(new_new_List)):
    new_new_new_List.append({'time': new_new_List[p]['time'], 'note': []})
    for q in new_new_List[p]['note']:
        s = (q[2] + 9) // 10
        for r in range(s):
            new_new_new_List[p]['note'].append((q[0], q[1]))

open('test_{}.mcfunction'.format(len(new_new_List)), mode='a', encoding='utf-8').write('fill ~{} ~{} ~{} ~{} ~{} ~{} minecraft:repeater[delay=4,facing=north]\n'.format(0, 0, 1, 0, 0, 1))

for o in range(2, z, 1):
    open('test_{}.mcfunction'.format(len(new_new_List)), mode='a', encoding='utf-8').write('fill ~{} ~{} ~{} ~{} ~{} ~{} minecraft:repeater[delay=4,facing=north]\n'.format(0, 0, o, 0, 0, o))

for k in range(len(new_new_new_List)):
    i = 0
    for j in range(7):
        for x in range(-14 + 2 * j, 15 - 2 * j, 1):
            y = 2 * j
            if x == -1 or x == 1:
                open('test_{}.mcfunction'.format(k), mode='a', encoding='utf-8').write('fill ~{} ~{} ~{} ~{} ~{} ~{} minecraft:sea_lantern\n'.format(x, y, z, x, y, z))
                open('test_{}.mcfunction'.format(k), mode='a', encoding='utf-8').write('fill ~{} ~{} ~{} ~{} ~{} ~{} minecraft:redstone_wire\n'.format(x, y+1, z, x, y+1, z))
            elif x == 0:
                if y != 12:
                    open('test_{}.mcfunction'.format(k), mode='a', encoding='utf-8').write('fill ~{} ~{} ~{} ~{} ~{} ~{} minecraft:sea_lantern\n'.format(x, y+1, z, x, y+1, z))
                    open('test_{}.mcfunction'.format(k), mode='a', encoding='utf-8').write('fill ~{} ~{} ~{} ~{} ~{} ~{} minecraft:redstone_wire\n'.format(x, y+2, z, x, y+2, z))
            else:
                open('test_{}.mcfunction'.format(k), mode='a', encoding='utf-8').write('fill ~{} ~{} ~{} ~{} ~{} ~{} minecraft:diamond_block\n'.format(x, y, z, x, y, z))
                open('test_{}.mcfunction'.format(k), mode='a', encoding='utf-8').write('fill ~{} ~{} ~{} ~{} ~{} ~{} minecraft:redstone_wire\n'.format(x, y+1, z, x, y+1, z))
                if j % 2 == x % 2:
                    if i < len(new_new_new_List[k]['note']):
                        open('test_{}.mcfunction'.format(k), mode='a', encoding='utf-8').write('fill ~{} ~{} ~{} ~{} ~{} ~{} tutorialmod:my_note[note={},instrument={}]\n'.format(x, y, z-1, x, y, z-1, new_new_new_List[k]['note'][i][1], channel[new_new_new_List[k]['note'][i][0]]))
                        i += 1  # tutorialmod:my_note
                    if i < len(new_new_new_List[k]['note']):
                        open('test_{}.mcfunction'.format(k), mode='a', encoding='utf-8').write('fill ~{} ~{} ~{} ~{} ~{} ~{} tutorialmod:my_note[note={},instrument={}]\n'.format(x, y, z+1, x, y, z+1, new_new_new_List[k]['note'][i][1], channel[new_new_new_List[k]['note'][i][0]]))
                        i += 1  # minecraft:note_block
    if k + 2 > len(new_new_new_List):
        open('test_{}.mcfunction'.format(len(new_new_List)), mode='a', encoding='utf-8').write('fill ~{} ~{} ~{} ~{} ~{} ~{} minecraft:redstone_wire\n'.format(0, 0, z, 0, 0, z))
        open('test_{}.mcfunction'.format(len(new_new_List)), mode='a', encoding='utf-8').write('fill ~{} ~{} ~{} ~{} ~{} ~{} minecraft:redstone_wire\n'.format(0, 0, z+1, 0, 0, z+1))
        open('test_{}.mcfunction'.format(len(new_new_List)), mode='a', encoding='utf-8').write('setblock ~{} ~{} ~{} minecraft:command_block[]{{Command:"title @p title \\"\\\\u00A7c{}\\""}}\n'.format(0, 0, z+2, name))
        open('test_{}.mcfunction'.format(len(new_new_List)), mode='a', encoding='utf-8').write('setblock ~{} ~{} ~{} minecraft:command_block[]{{Command:"title @p subtitle \\"\\\\u00A7d\\\\u00a7oby-ETO\\""}}\n'.format(0, 0, z+3))
    else:
        open('test_{}.mcfunction'.format(k), mode='a', encoding='utf-8').write('fill ~{} ~{} ~{} ~{} ~{} ~{} minecraft:redstone_wire\n'.format(0, 0, z, 0, 0, z))
        open('test_{}.mcfunction'.format(k), mode='a', encoding='utf-8').write('fill ~{} ~{} ~{} ~{} ~{} ~{} minecraft:redstone_wire\n'.format(0, 0, z+2, 0, 0, z+2))
        if new_new_new_List[k+1]['time'] % 2 == 0:
            open('test_{}.mcfunction'.format(k), mode='a', encoding='utf-8').write('fill ~{} ~{} ~{} ~{} ~{} ~{} minecraft:redstone_wire\n'.format(0, 0, z, 0, 0, z))
            open('test_{}.mcfunction'.format(k), mode='a', encoding='utf-8').write('fill ~{} ~{} ~{} ~{} ~{} ~{} minecraft:redstone_wire\n'.format(0, 0, z+1, 0, 0, z+1))
            z -= 1
            if new_new_new_List[k+1]['time'] < 9:
                open('test_{}.mcfunction'.format(k), mode='a', encoding='utf-8').write('fill ~{} ~{} ~{} ~{} ~{} ~{} minecraft:redstone_wire\n'.format(0, 0, z+2, 0, 0, z+2))
            z += 1
        elif new_new_new_List[k+1]['time'] % 2 == 1:
            open('test_{}.mcfunction'.format(k), mode='a', encoding='utf-8').write('fill ~{} ~{} ~{} ~{} ~{} ~{} minecraft:redstone_wire\n'.format(0, 0, z, 0, 0, z))
            open('test_{}.mcfunction'.format(k), mode='a', encoding='utf-8').write('fill ~{} ~{} ~{} ~{} ~{} ~{} minecraft:redstone_wire\n'.format(0, 0, z+1, 0, 0, z+1))
            open('test_{}.mcfunction'.format(k), mode='a', encoding='utf-8').write('fill ~{} ~{} ~{} ~{} ~{} ~{} minecraft:sticky_piston[facing=south]\n'.format(0, 0, z+2, 0, 0, z+2))
            open('test_{}.mcfunction'.format(k), mode='a', encoding='utf-8').write('fill ~{} ~{} ~{} ~{} ~{} ~{} minecraft:redstone_block\n'.format(0, 0, z+3, 0, 0, z+3))
            z += 2
    if k + 2 <= len(new_new_new_List):
        l = new_new_new_List[k+1]['time'] // 2
        n = (l + 3) // 4
        for m in range(n):
            if l >= 4:
                open('test_{}.mcfunction'.format(k), mode='a', encoding='utf-8').write('fill ~{} ~{} ~{} ~{} ~{} ~{} minecraft:repeater[delay=4,facing=north]\n'.format(0, 0, z+3+m, 0, 0, z+3+m))
                l -= 4
            elif l != 0:
                open('test_{}.mcfunction'.format(k), mode='a', encoding='utf-8').write('fill ~{} ~{} ~{} ~{} ~{} ~{} minecraft:repeater[delay={},facing=north]\n'.format(0, 0, z+3+m, 0, 0, z+3+m, l))
                l = 0
    if k + 2 <= len(new_new_new_List):
        z += (3 + (new_new_new_List[k+1]['time'] // 2 + 3) // 4)

for k in range(len(new_new_new_List) + 1):
    open('test.mcfunction', mode='a', encoding='utf-8').write('function redstone_music:test_{}\n'.format(k))

print(new_new_new_List)
print(len(new_new_new_List))
